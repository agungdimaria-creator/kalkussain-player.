package id.kalkussain.player

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private lateinit var seekBar: SeekBar
    private val mainExecutor: Executor by lazy { ContextCompat.getMainExecutor(this) }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            player?.setMediaItems(uris.map { MediaItem.fromUri(it) })
            player?.prepare()
            player?.play()
            status.text = "${uris.size} file audio dimasukkan ke antrean"
            playButton.text = "Ⅱ Jeda"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 14, 20)
        window.navigationBarColor = android.graphics.Color.rgb(11, 14, 20)
        buildUi()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                player = controllerFuture?.get()
                player?.addListener(object : androidx.media3.common.Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        playButton.text = if (isPlaying) "Ⅱ Jeda" else "▶ Putar"
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        status.text = mediaItem?.mediaMetadata?.title?.toString() ?: "Sedang memutar audio"
                    }
                })
            } catch (_: Exception) { status.text = "Gagal menghubungkan pemutar." }
        }, mainExecutor)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 22)
            setBackgroundColor(android.graphics.Color.rgb(11, 14, 20))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun text(value: String, size: Float, color: Int = 0xFFF4F6FB.toInt()): TextView =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(0, 7, 0, 7) }
        content.addView(text("♫  KALKUSSAIN PLAYER PRO", 22f))
        content.addView(text("NATIVE ANDROID • 10-BAND PARAMETRIC DSP", 10f, 0xFF42DFC2.toInt()))
        status = text("Belum ada lagu dipilih", 13f, 0xFF9AA8BB.toInt())
        content.addView(status)
        val buttons = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val add = Button(this).apply { text = "＋ Pilih Lagu"; setOnClickListener { picker.launch(arrayOf("audio/*")) } }
        playButton = Button(this).apply { text = "▶ Putar"; setOnClickListener {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        } }
        buttons.addView(add); buttons.addView(playButton)
        content.addView(buttons)
        content.addView(text("PARAMETRIC EQUALIZER", 17f))
        content.addView(text("Atur frekuensi, gain, dan Q secara terpisah untuk setiap band.", 12f, 0xFF9AA8BB.toInt()))
        val preset = Spinner(this)
        val names = listOf("Flat", "Bass", "Warm", "Vocal", "Bright")
        preset.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        preset.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val gains = listOf(
                    listOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f),
                    listOf(5f,4f,3f,1f,0f,0f,0f,1f,2f,2f),
                    listOf(2f,2f,1f,1f,0f,-1f,-1f,0f,1f,1f),
                    listOf(-2f,-1f,0f,2f,4f,4f,2f,1f,0f,-1f),
                    listOf(-2f,-1f,0f,0f,0f,1f,2f,3f,4f,4f)
                )[position]
                AudioDspConfig.bands = AudioDspConfig.bands.mapIndexed { i, b -> b.copy(gainDb = gains[i]) }
            }
        }
        content.addView(preset)
        val frequencies = listOf(31f,62f,125f,250f,500f,1000f,2000f,4000f,8000f,16000f)
        frequencies.forEachIndexed { index, initial ->
            val band = AudioDspConfig.bands[index]
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 8, 12, 8)
                setBackgroundColor(0xFF151C28.toInt())
            }
            val label = text("Band ${index + 1}  •  ${initial.toInt()} Hz", 13f)
            card.addView(label)
            card.addView(text("Frequency", 10f, 0xFF9AA8BB.toInt()))
            val freq = SeekBar(this).apply {
                max = 1000
                progress = (((kotlin.math.ln(initial / 20f) / kotlin.math.ln(20000f / 20f)) * 1000).toInt()).coerceIn(0,1000)
            }
            card.addView(freq)
            card.addView(text("Gain: 0 dB", 10f, 0xFF42DFC2.toInt()))
            val gain = SeekBar(this).apply { max = 480; progress = 240 }
            card.addView(gain)
            card.addView(text("Q-Factor: 1.0", 10f, 0xFF42DFC2.toInt()))
            val q = SeekBar(this).apply { max = 99; progress = 9 }
            card.addView(q)
            fun update() {
                val hz = 20f * (20000f / 20f).let { it.toDouble().pow(freq.progress / 1000.0).toFloat() }
                val db = (gain.progress - 240) / 20f
                val qv = 0.1f + q.progress / 10f
                label.text = "Band ${index + 1}  •  ${hz.toInt()} Hz"
                (card.getChildAt(3) as TextView).text = "Gain: %.1f dB".format(db)
                (card.getChildAt(5) as TextView).text = "Q-Factor: %.1f".format(qv)
                AudioDspConfig.bands = AudioDspConfig.bands.toMutableList().also {
                    it[index] = PeqBand(hz, db, qv)
                }
            }
            freq.setOnSeekBarChangeListener(simpleSeek { update() })
            gain.setOnSeekBarChangeListener(simpleSeek { update() })
            q.setOnSeekBarChangeListener(simpleSeek { update() })
            val params = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) }
            content.addView(card, params)
        }
        content.addView(text("OUTPUT & REVERB", 17f))
        val preampLabel = text("Preamp: 0 dB", 12f)
        content.addView(preampLabel)
        content.addView(SeekBar(this).apply {
            max = 480; progress = 240
            setOnSeekBarChangeListener(simpleSeek {
                AudioDspConfig.preampDb = (progress - 240) / 20f
                preampLabel.text = "Preamp: %.1f dB".format(AudioDspConfig.preampDb)
            })
        })
        val reverbLabel = text("Reverb mix: 0%", 12f)
        content.addView(reverbLabel)
        content.addView(SeekBar(this).apply {
            max = 70; progress = 0
            setOnSeekBarChangeListener(simpleSeek {
                AudioDspConfig.reverbMix = progress / 100f
                reverbLabel.text = "Reverb mix: ${progress}%"
            })
        })
        val roomLabel = text("Room size: 45%", 12f)
        content.addView(roomLabel)
        content.addView(SeekBar(this).apply {
            max = 85; progress = 35
            setOnSeekBarChangeListener(simpleSeek {
                AudioDspConfig.roomSize = (progress + 10) / 100f
                roomLabel.text = "Room size: ${progress + 10}%"
            })
        })
        content.addView(text("Audio diproses di perangkat. Putar audio untuk mengaktifkan DSP.", 11f, 0xFF9AA8BB.toInt()))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun simpleSeek(action: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) action() }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) { action() }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
