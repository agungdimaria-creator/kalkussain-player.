package id.kalkussain.player

import kotlin.math.pow

data class PeqBand(
    val frequency: Float,
    val gainDb: Float,
    val q: Float,
    val enabled: Boolean = true
)

object AudioDspConfig {
    @Volatile var bands: List<PeqBand> = listOf(
        PeqBand(31f, 0f, 1f), PeqBand(62f, 0f, 1f),
        PeqBand(125f, 0f, 1f), PeqBand(250f, 0f, 1f),
        PeqBand(500f, 0f, 1f), PeqBand(1000f, 0f, 1f),
        PeqBand(2000f, 0f, 1f), PeqBand(4000f, 0f, 1f),
        PeqBand(8000f, 0f, 1f), PeqBand(16000f, 0f, 1f)
    )
    @Volatile var preampDb: Float = 0f
    @Volatile var reverbMix: Float = 0f
    @Volatile var roomSize: Float = 0.45f
}
