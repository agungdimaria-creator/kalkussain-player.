package id.kalkussain.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Lightweight 10-band peaking parametric EQ for PCM 16-bit audio.
 * Frequency, gain and Q are independently adjustable per band.
 */
class ParametricEqAudioProcessor : AudioProcessor {
    private var inputFormat = AudioProcessor.AudioFormat.NOT_SET
    private var output = AudioProcessor.EMPTY_BUFFER
    private var sampleRate = 44100
    private var channels = 2
    private var filters = emptyArray<Biquad>()
    private var delay = Array(2) { FloatArray(1) }
    private var delayIndex = IntArray(2)
    private var lastBands: List<PeqBand> = emptyList()
    private var lastRate = 0

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        inputFormat = inputAudioFormat
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        rebuildFilters()
        return inputAudioFormat
    }

    override fun isActive(): Boolean = inputFormat != AudioProcessor.AudioFormat.NOT_SET
    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size <= 0) return
        if (lastBands != AudioDspConfig.bands || lastRate != sampleRate) rebuildFilters()
        val out = ByteBuffer.allocateDirect(size).order(ByteOrder.LITTLE_ENDIAN)
        val preamp = 10f.pow(AudioDspConfig.preampDb / 20f)
        val mix = AudioDspConfig.reverbMix.coerceIn(0f, 0.7f)
        val room = AudioDspConfig.roomSize.coerceIn(0.1f, 0.95f)
        val delaySamples = (sampleRate * (0.055f + room * 0.12f)).toInt().coerceAtLeast(1)
        ensureDelay(delaySamples + 1)
        while (inputBuffer.remaining() >= 2 * channels) {
            for (ch in 0 until channels) {
                var x = inputBuffer.short / 32768f
                for (f in filters) x = f.process(x, ch)
                x *= preamp
                val line = delay[ch.coerceAtMost(delay.size - 1)]
                val pos = delayIndex[ch.coerceAtMost(delayIndex.lastIndex)]
                val delayed = line[pos]
                line[pos] = (x + delayed * (0.22f + room * 0.28f)).coerceIn(-1.5f, 1.5f)
                delayIndex[ch.coerceAtMost(delayIndex.lastIndex)] = (pos + 1) % line.size
                x = x * (1f - mix) + delayed * mix
                out.putShort((x.coerceIn(-1f, 0.99997f) * 32767f).toInt().toShort())
            }
        }
        out.flip()
        output = out
    }

    private fun rebuildFilters() {
        val specs = AudioDspConfig.bands
        filters = specs.map { Biquad(sampleRate, it) }.toTypedArray()
        lastBands = specs.toList()
        lastRate = sampleRate
    }

    private fun ensureDelay(length: Int) {
        if (delay.firstOrNull()?.size != length || delay.size != channels) {
            delay = Array(channels) { FloatArray(length) }
            delayIndex = IntArray(channels)
        }
    }

    override fun queueEndOfStream() {}
    override fun getOutput(): ByteBuffer {
        val result = output
        output = AudioProcessor.EMPTY_BUFFER
        return result
    }
    override fun isEnded(): Boolean = output === AudioProcessor.EMPTY_BUFFER
    override fun flush() { output = AudioProcessor.EMPTY_BUFFER; ensureDelay((sampleRate * 0.2f).toInt()) }
    override fun reset() {
        flush()
        inputFormat = AudioProcessor.AudioFormat.NOT_SET
        filters = emptyArray()
        lastBands = emptyList()
    }

    private class Biquad(rate: Int, band: PeqBand) {
        private val b0: Float
        private val b1: Float
        private val b2: Float
        private val a1: Float
        private val a2: Float
        private val z1 = FloatArray(8)
        private val z2 = FloatArray(8)
        init {
            val f = band.frequency.coerceIn(20f, rate * 0.45f)
            val q = band.q.coerceIn(0.1f, 10f)
            val a = 10.0.pow((band.gainDb / 40.0).toDouble()).toFloat()
            val w = (2.0 * PI * f / rate).toFloat()
            val cw = cos(w); val sw = sin(w)
            val alpha = sw / (2f * q)
            val rb0 = 1f + alpha * a
            val rb1 = -2f * cw
            val rb2 = 1f - alpha * a
            val ra0 = 1f + alpha / a
            val ra1 = -2f * cw
            val ra2 = 1f - alpha / a
            b0 = rb0 / ra0; b1 = rb1 / ra0; b2 = rb2 / ra0
            a1 = ra1 / ra0; a2 = ra2 / ra0
        }
        fun process(input: Float, channel: Int): Float {
            val ch = channel.coerceIn(0, z1.lastIndex)
            val y = b0 * input + z1[ch]
            z1[ch] = b1 * input - a1 * y + z2[ch]
            z2[ch] = b2 * input - a2 * y
            return y
        }
    }
}
