# Kalkussain Player PRO — Native Android starter

Project Android native Kotlin dengan:
- Media3 ExoPlayer + MediaSessionService untuk pemutaran latar belakang dan notifikasi media.
- File picker Android untuk memilih audio dari perangkat.
- 10 band peaking parametric EQ; tiap band memiliki Frequency, Gain dan Q-Factor.
- Preset EQ, preamp, kontrol reverb ringan.
- GitHub Actions untuk menghasilkan APK debug otomatis.

## Build APK via GitHub (dari HP juga bisa)
1. Buat repository GitHub baru, misalnya `kalkussain-player`.
2. Upload seluruh isi folder project ini ke root repository (bukan folder ZIP-nya).
3. Buka tab **Actions**. Jika diminta, aktifkan Actions.
4. Pilih workflow **Build Kalkussain Android APK** lalu tekan **Run workflow**. Workflow juga berjalan otomatis saat push ke branch `main` atau `master`.
5. Setelah selesai hijau, buka hasil run → bagian **Artifacts** → unduh `kalkussain-player-debug-apk`.
6. Ekstrak ZIP artifact dan instal file APK di Android. Izinkan instalasi dari sumber tersebut bila diminta.

## Build lokal
Butuh JDK 17 dan Gradle 8.9:
`gradle assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Catatan penting
- Ini starter project, bukan rilis final yang sudah diuji pada beragam perangkat. Jalankan build GitHub; bila build gagal, kirim log error agar dapat diperbaiki.
- Pemrosesan PEQ berada pada jalur PCM 16-bit Media3. Codec/perangkat yang memerlukan format PCM lain dapat membutuhkan konfigurasi tambahan.
- Efek reverb saat ini berupa ambience/delay ringan, belum algoritma convolution/plate/hall kelas studio.
- Tampilan adalah UI native awal. Ikon, artwork, library scan, lock-screen controls, audio focus dan UX dapat disempurnakan.
- APK debug tidak ditandatangani untuk distribusi Play Store. Untuk distribusi umum perlu signing release.
- Hak akses file audio diminta melalui Android Storage Access Framework; file tidak diunggah ke server.
